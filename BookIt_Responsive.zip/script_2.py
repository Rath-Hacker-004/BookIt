
# Create the complete backend code for the booking system

backend_code = {
    "server.js": '''// BookIt Backend Server - Main Entry Point
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MongoDB Connection
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/bookit';

mongoose.connect(MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✓ Connected to MongoDB'))
.catch(err => console.error('MongoDB connection error:', err));

// Import Routes
const experiencesRouter = require('./routes/experiences');
const bookingsRouter = require('./routes/bookings');
const promoRouter = require('./routes/promo');

// Routes
app.get('/', (req, res) => {
  res.json({ 
    message: 'BookIt API Server', 
    version: '1.0.0',
    endpoints: {
      experiences: '/api/experiences',
      experienceById: '/api/experiences/:id',
      bookings: '/api/bookings',
      promoValidate: '/api/promo/validate'
    }
  });
});

app.use('/api/experiences', experiencesRouter);
app.use('/api/bookings', bookingsRouter);
app.use('/api/promo', promoRouter);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ 
    error: 'Internal server error',
    message: err.message 
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`✓ Server running on port ${PORT}`);
  console.log(`✓ API available at http://localhost:${PORT}`);
});

module.exports = app;
''',

    ".env.example": '''# MongoDB Configuration
MONGO_URI=mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/bookit?retryWrites=true&w=majority

# Server Configuration
PORT=5000
NODE_ENV=development

# Frontend URL (for CORS)
CLIENT_URL=http://localhost:5173
''',

    "package.json": '''{
  "name": "bookit-backend",
  "version": "1.0.0",
  "description": "Backend API for BookIt travel booking platform",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js",
    "seed": "node scripts/seedData.js"
  },
  "keywords": ["booking", "travel", "express", "mongodb"],
  "author": "",
  "license": "ISC",
  "dependencies": {
    "express": "^4.18.2",
    "mongoose": "^7.5.0",
    "cors": "^2.8.5",
    "dotenv": "^16.3.1",
    "express-validator": "^7.0.1"
  },
  "devDependencies": {
    "nodemon": "^3.0.1"
  }
}
''',

    "models/Experience.js": '''const mongoose = require('mongoose');

const slotSchema = new mongoose.Schema({
  date: {
    type: String,
    required: true
  },
  times: [{
    type: String,
    required: true
  }],
  available: {
    type: Number,
    required: true,
    min: 0
  },
  total: {
    type: Number,
    required: true
  }
});

const experienceSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  location: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    required: true,
    min: 0
  },
  currency: {
    type: String,
    default: 'INR'
  },
  duration: {
    type: String,
    required: true
  },
  image: {
    type: String,
    required: true
  },
  rating: {
    type: Number,
    min: 0,
    max: 5,
    default: 0
  },
  reviews: {
    type: Number,
    default: 0
  },
  category: {
    type: String,
    required: true
  },
  highlights: [{
    type: String
  }],
  slots: [slotSchema],
  active: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Experience', experienceSchema);
''',

    "models/Booking.js": '''const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  bookingReference: {
    type: String,
    required: true,
    unique: true
  },
  experience: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Experience',
    required: true
  },
  customerName: {
    type: String,
    required: true,
    trim: true
  },
  customerEmail: {
    type: String,
    required: true,
    trim: true,
    lowercase: true
  },
  customerPhone: {
    type: String,
    required: true,
    trim: true
  },
  selectedDate: {
    type: String,
    required: true
  },
  selectedTime: {
    type: String,
    required: true
  },
  guests: {
    type: Number,
    required: true,
    min: 1,
    max: 10
  },
  specialRequests: {
    type: String,
    default: ''
  },
  promoCode: {
    type: String,
    default: null
  },
  discount: {
    type: Number,
    default: 0
  },
  basePrice: {
    type: Number,
    required: true
  },
  totalPrice: {
    type: Number,
    required: true
  },
  status: {
    type: String,
    enum: ['confirmed', 'cancelled', 'pending'],
    default: 'confirmed'
  }
}, {
  timestamps: true
});

// Generate unique booking reference
bookingSchema.pre('save', function(next) {
  if (!this.bookingReference) {
    this.bookingReference = 'BK' + Date.now() + Math.random().toString(36).substr(2, 9).toUpperCase();
  }
  next();
});

module.exports = mongoose.model('Booking', bookingSchema);
''',

    "models/PromoCode.js": '''const mongoose = require('mongoose');

const promoCodeSchema = new mongoose.Schema({
  code: {
    type: String,
    required: true,
    unique: true,
    uppercase: true,
    trim: true
  },
  discountType: {
    type: String,
    enum: ['percentage', 'fixed'],
    required: true
  },
  discountValue: {
    type: Number,
    required: true,
    min: 0
  },
  description: {
    type: String,
    required: true
  },
  minAmount: {
    type: Number,
    default: 0
  },
  maxDiscount: {
    type: Number,
    default: null
  },
  active: {
    type: Boolean,
    default: true
  },
  validFrom: {
    type: Date,
    default: Date.now
  },
  validUntil: {
    type: Date,
    default: null
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('PromoCode', promoCodeSchema);
''',

    "routes/experiences.js": '''const express = require('express');
const router = express.Router();
const Experience = require('../models/Experience');

// GET /api/experiences - Get all experiences
router.get('/', async (req, res) => {
  try {
    const experiences = await Experience.find({ active: true })
      .select('-__v')
      .sort({ createdAt: -1 });
    
    res.json({
      success: true,
      count: experiences.length,
      data: experiences
    });
  } catch (error) {
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

// GET /api/experiences/:id - Get single experience
router.get('/:id', async (req, res) => {
  try {
    const experience = await Experience.findById(req.params.id)
      .select('-__v');
    
    if (!experience) {
      return res.status(404).json({ 
        success: false,
        error: 'Experience not found' 
      });
    }

    res.json({
      success: true,
      data: experience
    });
  } catch (error) {
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ 
        success: false,
        error: 'Experience not found' 
      });
    }
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

// PATCH /api/experiences/:id/slots - Update slot availability
router.patch('/:id/slots', async (req, res) => {
  try {
    const { date, time, decrement } = req.body;
    
    const experience = await Experience.findById(req.params.id);
    
    if (!experience) {
      return res.status(404).json({ 
        success: false,
        error: 'Experience not found' 
      });
    }

    // Find and update the specific slot
    const slot = experience.slots.find(s => s.date === date);
    if (slot && slot.times.includes(time)) {
      slot.available = Math.max(0, slot.available - decrement);
      await experience.save();
      
      res.json({
        success: true,
        data: experience
      });
    } else {
      res.status(400).json({ 
        success: false,
        error: 'Slot not found' 
      });
    }
  } catch (error) {
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

module.exports = router;
''',

    "routes/bookings.js": '''const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Booking = require('../models/Booking');
const Experience = require('../models/Experience');

// Validation middleware
const bookingValidation = [
  body('experienceId').notEmpty().withMessage('Experience ID is required'),
  body('customerName').trim().isLength({ min: 2 }).withMessage('Name must be at least 2 characters'),
  body('customerEmail').isEmail().normalizeEmail().withMessage('Valid email is required'),
  body('customerPhone').matches(/^[0-9]{10}$/).withMessage('Phone must be 10 digits'),
  body('selectedDate').notEmpty().withMessage('Date is required'),
  body('selectedTime').notEmpty().withMessage('Time is required'),
  body('guests').isInt({ min: 1, max: 10 }).withMessage('Guests must be between 1 and 10')
];

// POST /api/bookings - Create new booking
router.post('/', bookingValidation, async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false,
        errors: errors.array() 
      });
    }

    const {
      experienceId,
      customerName,
      customerEmail,
      customerPhone,
      selectedDate,
      selectedTime,
      guests,
      specialRequests,
      promoCode,
      discount,
      basePrice,
      totalPrice
    } = req.body;

    // Verify experience exists
    const experience = await Experience.findById(experienceId);
    if (!experience) {
      return res.status(404).json({ 
        success: false,
        error: 'Experience not found' 
      });
    }

    // Check slot availability
    const slot = experience.slots.find(s => s.date === selectedDate);
    if (!slot || !slot.times.includes(selectedTime)) {
      return res.status(400).json({ 
        success: false,
        error: 'Selected slot not available' 
      });
    }

    if (slot.available < guests) {
      return res.status(400).json({ 
        success: false,
        error: `Only ${slot.available} spots available` 
      });
    }

    // Create booking
    const booking = new Booking({
      experience: experienceId,
      customerName,
      customerEmail,
      customerPhone,
      selectedDate,
      selectedTime,
      guests,
      specialRequests,
      promoCode,
      discount,
      basePrice,
      totalPrice
    });

    await booking.save();

    // Update slot availability
    slot.available -= guests;
    await experience.save();

    // Populate experience details
    await booking.populate('experience', 'title location image');

    res.status(201).json({
      success: true,
      message: 'Booking created successfully',
      data: booking
    });

  } catch (error) {
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

// GET /api/bookings/:reference - Get booking by reference
router.get('/:reference', async (req, res) => {
  try {
    const booking = await Booking.findOne({ 
      bookingReference: req.params.reference 
    }).populate('experience', 'title location image duration');

    if (!booking) {
      return res.status(404).json({ 
        success: false,
        error: 'Booking not found' 
      });
    }

    res.json({
      success: true,
      data: booking
    });
  } catch (error) {
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

// GET /api/bookings - Get all bookings (admin)
router.get('/', async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate('experience', 'title location')
      .sort({ createdAt: -1 })
      .limit(100);

    res.json({
      success: true,
      count: bookings.length,
      data: bookings
    });
  } catch (error) {
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

module.exports = router;
''',

    "routes/promo.js": '''const express = require('express');
const router = express.Router();
const PromoCode = require('../models/PromoCode');

// POST /api/promo/validate - Validate promo code
router.post('/validate', async (req, res) => {
  try {
    const { code, amount } = req.body;

    if (!code || !amount) {
      return res.status(400).json({ 
        success: false,
        error: 'Code and amount are required' 
      });
    }

    // Find promo code
    const promo = await PromoCode.findOne({ 
      code: code.toUpperCase(),
      active: true 
    });

    if (!promo) {
      return res.status(404).json({ 
        success: false,
        error: 'Invalid promo code' 
      });
    }

    // Check validity dates
    const now = new Date();
    if (promo.validUntil && promo.validUntil < now) {
      return res.status(400).json({ 
        success: false,
        error: 'Promo code has expired' 
      });
    }

    // Check minimum amount
    if (amount < promo.minAmount) {
      return res.status(400).json({ 
        success: false,
        error: `Minimum order amount is ₹${promo.minAmount}` 
      });
    }

    // Calculate discount
    let discount = 0;
    if (promo.discountType === 'percentage') {
      discount = (amount * promo.discountValue) / 100;
      if (promo.maxDiscount) {
        discount = Math.min(discount, promo.maxDiscount);
      }
    } else {
      discount = promo.discountValue;
    }

    discount = Math.round(discount);

    res.json({
      success: true,
      message: 'Promo code applied successfully',
      data: {
        code: promo.code,
        description: promo.description,
        discountType: promo.discountType,
        discountValue: promo.discountValue,
        discount: discount,
        finalAmount: amount - discount
      }
    });

  } catch (error) {
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

// GET /api/promo - Get all active promo codes
router.get('/', async (req, res) => {
  try {
    const promos = await PromoCode.find({ active: true })
      .select('-__v')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      count: promos.length,
      data: promos
    });
  } catch (error) {
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

module.exports = router;
''',

    "scripts/seedData.js": '''const mongoose = require('mongoose');
const Experience = require('../models/Experience');
const PromoCode = require('../models/PromoCode');
require('dotenv').config();

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/bookit';

const experiences = [
  {
    title: "Himalayan Trek Adventure",
    description: "Experience the breathtaking beauty of the Himalayas with our guided trekking adventure. Journey through pristine mountain landscapes, traditional villages, and witness stunning sunrise views from high-altitude camps.",
    location: "Himachal Pradesh, India",
    price: 12500,
    currency: "INR",
    duration: "7 days",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800",
    rating: 4.8,
    reviews: 234,
    category: "Adventure",
    highlights: [
      "Professional mountain guides",
      "All meals included",
      "Camping equipment provided",
      "Small group sizes (max 12)",
      "First aid support"
    ],
    slots: [
      { date: "2025-11-15", times: ["06:00 AM", "08:00 AM"], available: 12, total: 15 },
      { date: "2025-11-22", times: ["06:00 AM", "08:00 AM"], available: 8, total: 15 },
      { date: "2025-11-29", times: ["06:00 AM"], available: 15, total: 15 },
      { date: "2025-12-06", times: ["06:00 AM", "08:00 AM"], available: 10, total: 15 }
    ]
  },
  // Additional experiences data...
];

const promoCodes = [
  {
    code: "SAVE10",
    discountType: "percentage",
    discountValue: 10,
    description: "Get 10% off on your booking",
    minAmount: 2000,
    maxDiscount: 2000,
    active: true
  },
  {
    code: "FLAT100",
    discountType: "fixed",
    discountValue: 100,
    description: "Flat ₹100 off on all bookings",
    minAmount: 1000,
    maxDiscount: 100,
    active: true
  },
  {
    code: "FIRSTTRIP",
    discountType: "percentage",
    discountValue: 15,
    description: "15% off for first-time travelers",
    minAmount: 5000,
    maxDiscount: 3000,
    active: true
  },
  {
    code: "WELCOME500",
    discountType: "fixed",
    discountValue: 500,
    description: "Welcome bonus: ₹500 off",
    minAmount: 8000,
    maxDiscount: 500,
    active: true
  }
];

async function seedDatabase() {
  try {
    await mongoose.connect(MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log('✓ Connected to MongoDB');

    // Clear existing data
    await Experience.deleteMany({});
    await PromoCode.deleteMany({});
    console.log('✓ Cleared existing data');

    // Insert experiences
    await Experience.insertMany(experiences);
    console.log(`✓ Inserted ${experiences.length} experiences`);

    // Insert promo codes
    await PromoCode.insertMany(promoCodes);
    console.log(`✓ Inserted ${promoCodes.length} promo codes`);

    console.log('\\n✓ Database seeded successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
}

seedDatabase();
'''
}

# Save backend files
for filename, content in backend_code.items():
    with open(f'backend_{filename.replace("/", "_")}', 'w') as f:
        f.write(content)

print("✓ Created all backend code files:")
for filename in backend_code.keys():
    print(f"  - {filename}")
