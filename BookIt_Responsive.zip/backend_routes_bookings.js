const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Booking = require('../models/Booking');
const Experience = require('../models/Experience');

// Validation middleware
const bookingValidation = [
  body('experienceId').notEmpty().withMessage('Experience ID is required'),
  body('customerName').trim().isLength({ min: 2 }).withMessage('Name must be at least 2 characters'),
  body('customerEmail').isEmail().normalizeEmail().withMessage('Valid email is required'),
  body('customerPhone').matches(/^[0-9]{10}$/).withMessage('Phone must be 10 digits'),
  body('selectedDate').notEmpty().withMessage('Date is required'),
  body('selectedTime').notEmpty().withMessage('Time is required'),
  body('guests').isInt({ min: 1, max: 10 }).withMessage('Guests must be between 1 and 10')
];

// POST /api/bookings - Create new booking
router.post('/', bookingValidation, async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false,
        errors: errors.array() 
      });
    }

    const {
      experienceId,
      customerName,
      customerEmail,
      customerPhone,
      selectedDate,
      selectedTime,
      guests,
      specialRequests,
      promoCode,
      discount,
      basePrice,
      totalPrice
    } = req.body;

    // Verify experience exists
    const experience = await Experience.findById(experienceId);
    if (!experience) {
      return res.status(404).json({ 
        success: false,
        error: 'Experience not found' 
      });
    }

    // Check slot availability
    const slot = experience.slots.find(s => s.date === selectedDate);
    if (!slot || !slot.times.includes(selectedTime)) {
      return res.status(400).json({ 
        success: false,
        error: 'Selected slot not available' 
      });
    }

    if (slot.available < guests) {
      return res.status(400).json({ 
        success: false,
        error: `Only ${slot.available} spots available` 
      });
    }

    // Create booking
    const booking = new Booking({
      experience: experienceId,
      customerName,
      customerEmail,
      customerPhone,
      selectedDate,
      selectedTime,
      guests,
      specialRequests,
      promoCode,
      discount,
      basePrice,
      totalPrice
    });

    await booking.save();

    // Update slot availability
    slot.available -= guests;
    await experience.save();

    // Populate experience details
    await booking.populate('experience', 'title location image');

    res.status(201).json({
      success: true,
      message: 'Booking created successfully',
      data: booking
    });

  } catch (error) {
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

// GET /api/bookings/:reference - Get booking by reference
router.get('/:reference', async (req, res) => {
  try {
    const booking = await Booking.findOne({ 
      bookingReference: req.params.reference 
    }).populate('experience', 'title location image duration');

    if (!booking) {
      return res.status(404).json({ 
        success: false,
        error: 'Booking not found' 
      });
    }

    res.json({
      success: true,
      data: booking
    });
  } catch (error) {
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

// GET /api/bookings - Get all bookings (admin)
router.get('/', async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate('experience', 'title location')
      .sort({ createdAt: -1 })
      .limit(100);

    res.json({
      success: true,
      count: bookings.length,
      data: bookings
    });
  } catch (error) {
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

module.exports = router;
