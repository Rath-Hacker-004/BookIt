const express = require('express');
const router = express.Router();
const Experience = require('../models/Experience');

// GET /api/experiences - Get all experiences
router.get('/', async (req, res) => {
  try {
    const experiences = await Experience.find({ active: true })
      .select('-__v')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      count: experiences.length,
      data: experiences
    });
  } catch (error) {
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

// GET /api/experiences/:id - Get single experience
router.get('/:id', async (req, res) => {
  try {
    const experience = await Experience.findById(req.params.id)
      .select('-__v');

    if (!experience) {
      return res.status(404).json({ 
        success: false,
        error: 'Experience not found' 
      });
    }

    res.json({
      success: true,
      data: experience
    });
  } catch (error) {
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ 
        success: false,
        error: 'Experience not found' 
      });
    }
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

// PATCH /api/experiences/:id/slots - Update slot availability
router.patch('/:id/slots', async (req, res) => {
  try {
    const { date, time, decrement } = req.body;

    const experience = await Experience.findById(req.params.id);

    if (!experience) {
      return res.status(404).json({ 
        success: false,
        error: 'Experience not found' 
      });
    }

    // Find and update the specific slot
    const slot = experience.slots.find(s => s.date === date);
    if (slot && slot.times.includes(time)) {
      slot.available = Math.max(0, slot.available - decrement);
      await experience.save();

      res.json({
        success: true,
        data: experience
      });
    } else {
      res.status(400).json({ 
        success: false,
        error: 'Slot not found' 
      });
    }
  } catch (error) {
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

module.exports = router;
