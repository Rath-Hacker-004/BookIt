
# Create promo codes data
promo_codes = [
    {
        "code": "SAVE10",
        "discount_type": "percentage",
        "discount_value": 10,
        "description": "Get 10% off on your booking",
        "min_amount": 2000,
        "max_discount": 2000,
        "active": True
    },
    {
        "code": "FLAT100",
        "discount_type": "fixed",
        "discount_value": 100,
        "description": "Flat ₹100 off on all bookings",
        "min_amount": 1000,
        "max_discount": 100,
        "active": True
    },
    {
        "code": "FIRSTTRIP",
        "discount_type": "percentage",
        "discount_value": 15,
        "description": "15% off for first-time travelers",
        "min_amount": 5000,
        "max_discount": 3000,
        "active": True
    },
    {
        "code": "WELCOME500",
        "discount_type": "fixed",
        "discount_value": 500,
        "description": "Welcome bonus: ₹500 off",
        "min_amount": 8000,
        "max_discount": 500,
        "active": True
    }
]

with open('promo_codes.json', 'w') as f:
    json.dump(promo_codes, indent=2, fp=f)

print("✓ Created promo_codes.json with 4 promo codes")
print("\nAvailable promo codes:")
for promo in promo_codes:
    print(f"- {promo['code']}: {promo['description']}")
