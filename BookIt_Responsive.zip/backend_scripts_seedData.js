const mongoose = require('mongoose');
const Experience = require('../models/Experience');
const PromoCode = require('../models/PromoCode');
require('dotenv').config();

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/bookit';

const experiences = [
  {
    title: "Himalayan Trek Adventure",
    description: "Experience the breathtaking beauty of the Himalayas with our guided trekking adventure. Journey through pristine mountain landscapes, traditional villages, and witness stunning sunrise views from high-altitude camps.",
    location: "Himachal Pradesh, India",
    price: 12500,
    currency: "INR",
    duration: "7 days",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800",
    rating: 4.8,
    reviews: 234,
    category: "Adventure",
    highlights: [
      "Professional mountain guides",
      "All meals included",
      "Camping equipment provided",
      "Small group sizes (max 12)",
      "First aid support"
    ],
    slots: [
      { date: "2025-11-15", times: ["06:00 AM", "08:00 AM"], available: 12, total: 15 },
      { date: "2025-11-22", times: ["06:00 AM", "08:00 AM"], available: 8, total: 15 },
      { date: "2025-11-29", times: ["06:00 AM"], available: 15, total: 15 },
      { date: "2025-12-06", times: ["06:00 AM", "08:00 AM"], available: 10, total: 15 }
    ]
  },
  // Additional experiences data...
];

const promoCodes = [
  {
    code: "SAVE10",
    discountType: "percentage",
    discountValue: 10,
    description: "Get 10% off on your booking",
    minAmount: 2000,
    maxDiscount: 2000,
    active: true
  },
  {
    code: "FLAT100",
    discountType: "fixed",
    discountValue: 100,
    description: "Flat ₹100 off on all bookings",
    minAmount: 1000,
    maxDiscount: 100,
    active: true
  },
  {
    code: "FIRSTTRIP",
    discountType: "percentage",
    discountValue: 15,
    description: "15% off for first-time travelers",
    minAmount: 5000,
    maxDiscount: 3000,
    active: true
  },
  {
    code: "WELCOME500",
    discountType: "fixed",
    discountValue: 500,
    description: "Welcome bonus: ₹500 off",
    minAmount: 8000,
    maxDiscount: 500,
    active: true
  }
];

async function seedDatabase() {
  try {
    await mongoose.connect(MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log('✓ Connected to MongoDB');

    // Clear existing data
    await Experience.deleteMany({});
    await PromoCode.deleteMany({});
    console.log('✓ Cleared existing data');

    // Insert experiences
    await Experience.insertMany(experiences);
    console.log(`✓ Inserted ${experiences.length} experiences`);

    // Insert promo codes
    await PromoCode.insertMany(promoCodes);
    console.log(`✓ Inserted ${promoCodes.length} promo codes`);

    console.log('\n✓ Database seeded successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
}

seedDatabase();
