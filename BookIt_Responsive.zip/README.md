# BookIt: Experiences & Slots 🌍

A complete fullstack travel booking platform built with React, TypeScript, TailwindCSS, Node.js, Express, and MongoDB.

![BookIt Platform](https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=1200)

## 🚀 Live Demo

- **Frontend**: [View Live Application](https://ppl-ai-code-interpreter-files.s3.amazonaws.com/web/direct-files/5748edb604704f74e17167893732c492/34a1fa93-57c9-4317-8b23-58a8a3e3618b/index.html)
- **Backend API**: Deploy to your cloud platform (instructions below)

## 📋 Table of Contents

- [Features](#features)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Getting Started](#getting-started)
- [API Documentation](#api-documentation)
- [Deployment](#deployment)
- [Screenshots](#screenshots)
- [Contributing](#contributing)

## ✨ Features

### User Features
- 🏞️ **Browse Experiences**: View curated travel experiences with images, ratings, and pricing
- 📅 **Date & Time Selection**: Choose from available dates and time slots
- 💳 **Promo Codes**: Apply discount codes (SAVE10, FLAT100, FIRSTTRIP, WELCOME500)
- 📱 **Fully Responsive**: Optimized for mobile, tablet, and desktop
- ✅ **Form Validation**: Real-time validation for all user inputs
- 🎫 **Booking Confirmation**: Unique booking reference number generation

### Technical Features
- ⚡ **Fast Loading**: Built with Vite for optimal performance
- 🎨 **Modern UI**: TailwindCSS for beautiful, consistent design
- 🔒 **Type Safety**: TypeScript for better code quality
- 🌐 **RESTful API**: Well-structured backend with Express.js
- 🗄️ **MongoDB**: Robust data persistence with Mongoose
- 🚫 **Double-booking Prevention**: Atomic slot availability updates

## 🛠️ Tech Stack

### Frontend
- **React 18** - UI library
- **TypeScript** - Type safety
- **Vite** - Build tool
- **TailwindCSS** - Styling
- **React Context API** - State management

### Backend
- **Node.js** - Runtime
- **Express.js** - Web framework
- **MongoDB** - Database
- **Mongoose** - ODM
- **Express Validator** - Input validation

## 📁 Project Structure

```
bookit/
├── frontend/                  # React frontend
│   ├── src/
│   │   ├── components/       # Reusable components
│   │   ├── contexts/         # React contexts
│   │   ├── pages/            # Page components
│   │   ├── App.tsx           # Main app component
│   │   └── main.tsx          # Entry point
│   ├── index.html
│   ├── package.json
│   ├── tailwind.config.js
│   └── vite.config.ts
│
├── backend/                   # Node.js backend
│   ├── models/               # Mongoose models
│   │   ├── Experience.js
│   │   ├── Booking.js
│   │   └── PromoCode.js
│   ├── routes/               # API routes
│   │   ├── experiences.js
│   │   ├── bookings.js
│   │   └── promo.js
│   ├── scripts/
│   │   └── seedData.js       # Database seeder
│   ├── server.js             # Main server file
│   ├── package.json
│   └── .env.example
│
└── README.md
```

## 🚦 Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn
- MongoDB Atlas account (or local MongoDB)
- Git

### Backend Setup

1. **Clone the repository**
```bash
git clone <your-repo-url>
cd bookit/backend
```

2. **Install dependencies**
```bash
npm install
```

3. **Set up environment variables**
```bash
cp .env.example .env
```

Edit `.env` file:
```env
MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/bookit
PORT=5000
NODE_ENV=development
CLIENT_URL=http://localhost:5173
```

4. **Set up MongoDB Atlas**
   - Create account at [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
   - Create new cluster (free M0 tier)
   - Create database user with password
   - Whitelist IP: `0.0.0.0/0` (for development)
   - Get connection string and update `MONGO_URI`

5. **Seed the database**
```bash
npm run seed
```

6. **Start the server**
```bash
npm run dev
```

Server runs on `http://localhost:5000`

### Frontend Setup

1. **Navigate to frontend directory**
```bash
cd ../frontend
```

2. **Install dependencies**
```bash
npm install
```

3. **Set up environment variables**
```bash
echo "VITE_API_URL=http://localhost:5000/api" > .env
```

4. **Start development server**
```bash
npm run dev
```

Application runs on `http://localhost:5173`

## 📚 API Documentation

### Base URL
```
http://localhost:5000/api
```

### Endpoints

#### Experiences

**GET /experiences**
- Get all active experiences
- Response: Array of experience objects

**GET /experiences/:id**
- Get single experience by ID
- Response: Experience object with slots

**PATCH /experiences/:id/slots**
- Update slot availability
- Body: `{ date, time, decrement }`

#### Bookings

**POST /bookings**
- Create new booking
- Body:
```json
{
  "experienceId": "string",
  "customerName": "string",
  "customerEmail": "email",
  "customerPhone": "10-digit-number",
  "selectedDate": "string",
  "selectedTime": "string",
  "guests": "number (1-10)",
  "specialRequests": "string (optional)",
  "promoCode": "string (optional)",
  "discount": "number",
  "basePrice": "number",
  "totalPrice": "number"
}
```

**GET /bookings/:reference**
- Get booking by reference number
- Response: Booking object

**GET /bookings**
- Get all bookings (admin)
- Response: Array of bookings

#### Promo Codes

**POST /promo/validate**
- Validate promo code
- Body: `{ code, amount }`
- Response: Discount details

**GET /promo**
- Get all active promo codes
- Response: Array of promo codes

### Available Promo Codes

| Code | Type | Discount | Min Amount | Max Discount |
|------|------|----------|------------|--------------|
| SAVE10 | Percentage | 10% | ₹2,000 | ₹2,000 |
| FLAT100 | Fixed | ₹100 | ₹1,000 | ₹100 |
| FIRSTTRIP | Percentage | 15% | ₹5,000 | ₹3,000 |
| WELCOME500 | Fixed | ₹500 | ₹8,000 | ₹500 |

## 🚀 Deployment

### Backend Deployment (Render)

1. Create account at [Render](https://render.com)
2. Click "New +" → "Web Service"
3. Connect your GitHub repository
4. Configure:
   - **Environment**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
5. Add environment variables from `.env`
6. Click "Create Web Service"

### Backend Deployment (Railway)

1. Create account at [Railway](https://railway.app)
2. Click "New Project" → "Deploy from GitHub"
3. Select your repository
4. Add environment variables
5. Railway auto-deploys

### Frontend Deployment (Vercel)

1. Update `.env.production`:
```env
VITE_API_URL=https://your-backend-url.com/api
```

2. Build the application:
```bash
npm run build
```

3. Deploy using Vercel CLI:
```bash
npm install -g vercel
vercel
```

Or use [Vercel Dashboard](https://vercel.com):
- Import project from GitHub
- Framework preset: Vite
- Build command: `npm run build`
- Output directory: `dist`
- Add environment variables
- Deploy

## 📸 Screenshots

### Home Page
Browse all available travel experiences with beautiful cards showing images, pricing, and ratings.

### Details Page
View complete experience information, select dates and time slots, and check real-time availability.

### Checkout Page
Fill in your details, apply promo codes, and review your booking before confirmation.

### Result Page
Get your unique booking reference number and confirmation details.

## 🧪 Testing

### Manual Testing Checklist

**Home Page**
- [ ] Experiences load correctly
- [ ] Cards are clickable
- [ ] Responsive on all devices

**Details Page**
- [ ] Date selection works
- [ ] Time slots display for selected date
- [ ] Sold-out slots are disabled
- [ ] Proceed button enables when slot selected

**Checkout Page**
- [ ] Form validation works
- [ ] Promo codes apply correctly
- [ ] Price calculations accurate
- [ ] Booking submission successful

**API Testing**
Use Postman or Thunder Client:
- Test all GET endpoints
- Test POST with valid/invalid data
- Verify validation errors
- Check database updates

## 🔧 Environment Variables

### Backend (.env)
```env
MONGO_URI=<your-mongodb-connection-string>
PORT=5000
NODE_ENV=development
CLIENT_URL=http://localhost:5173
```

### Frontend (.env)
```env
VITE_API_URL=http://localhost:5000/api
```

## 🐛 Troubleshooting

### MongoDB Connection Error
- Verify connection string format
- Check database user credentials
- Whitelist IP address in MongoDB Atlas
- Ensure network connectivity

### CORS Error
- Add frontend URL to CORS configuration
- Verify environment variables
- Check protocol (http vs https)

### Build Fails
- Clear node_modules: `rm -rf node_modules`
- Reinstall: `npm install`
- Check Node.js version: `node --version`
- Verify TypeScript compilation

## 📝 License

This project is licensed under the MIT License.

## 👨‍💻 Author

Created for Fullstack Intern Assignment

## 🙏 Acknowledgments

- Images from [Unsplash](https://unsplash.com)
- Icons from TailwindCSS
- Inspiration from modern travel booking platforms

## 📞 Support

For issues or questions:
- Create an issue on GitHub
- Contact: [Your Email]

---

**Happy Coding! 🚀**
