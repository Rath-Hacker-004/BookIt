
# Create comprehensive sample travel experiences data for the booking application
import json

# Sample travel experiences with detailed information
experiences = [
    {
        "id": 1,
        "title": "Himalayan Trek Adventure",
        "description": "Experience the breathtaking beauty of the Himalayas with our guided trekking adventure. Journey through pristine mountain landscapes, traditional villages, and witness stunning sunrise views from high-altitude camps.",
        "location": "Himachal Pradesh, India",
        "price": 12500,
        "currency": "INR",
        "duration": "7 days",
        "image": "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800",
        "rating": 4.8,
        "reviews": 234,
        "category": "Adventure",
        "highlights": [
            "Professional mountain guides",
            "All meals included",
            "Camping equipment provided",
            "Small group sizes (max 12)",
            "First aid support"
        ],
        "slots": [
            {
                "date": "2025-11-15",
                "times": ["06:00 AM", "08:00 AM"],
                "available": 12,
                "total": 15
            },
            {
                "date": "2025-11-22",
                "times": ["06:00 AM", "08:00 AM"],
                "available": 8,
                "total": 15
            },
            {
                "date": "2025-11-29",
                "times": ["06:00 AM"],
                "available": 15,
                "total": 15
            },
            {
                "date": "2025-12-06",
                "times": ["06:00 AM", "08:00 AM"],
                "available": 10,
                "total": 15
            }
        ]
    },
    {
        "id": 2,
        "title": "Kerala Backwater Cruise",
        "description": "Sail through the serene backwaters of Kerala on a traditional houseboat. Enjoy authentic Kerala cuisine, witness local life along the waterways, and relax in the peaceful ambiance of God's Own Country.",
        "location": "Alleppey, Kerala",
        "price": 8500,
        "currency": "INR",
        "duration": "2 days / 1 night",
        "image": "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=800",
        "rating": 4.9,
        "reviews": 456,
        "category": "Leisure",
        "highlights": [
            "Traditional houseboat stay",
            "Kerala cuisine included",
            "Private boat option available",
            "Sunset cruise experience",
            "Local guide assistance"
        ],
        "slots": [
            {
                "date": "2025-11-10",
                "times": ["02:00 PM"],
                "available": 3,
                "total": 6
            },
            {
                "date": "2025-11-17",
                "times": ["02:00 PM"],
                "available": 5,
                "total": 6
            },
            {
                "date": "2025-11-24",
                "times": ["02:00 PM"],
                "available": 6,
                "total": 6
            },
            {
                "date": "2025-12-01",
                "times": ["02:00 PM"],
                "available": 4,
                "total": 6
            }
        ]
    },
    {
        "id": 3,
        "title": "Rajasthan Desert Safari",
        "description": "Embark on an unforgettable desert adventure in the golden sands of Rajasthan. Experience camel rides, traditional Rajasthani culture, folk performances, and spend a night under the stars in luxury desert camps.",
        "location": "Jaisalmer, Rajasthan",
        "price": 6500,
        "currency": "INR",
        "duration": "3 days / 2 nights",
        "image": "https://images.unsplash.com/photo-1548013146-72479768bada?w=800",
        "rating": 4.7,
        "reviews": 389,
        "category": "Cultural",
        "highlights": [
            "Camel safari included",
            "Cultural folk performances",
            "Luxury desert camping",
            "Traditional Rajasthani meals",
            "Jeep safari option"
        ],
        "slots": [
            {
                "date": "2025-11-12",
                "times": ["09:00 AM", "03:00 PM"],
                "available": 20,
                "total": 25
            },
            {
                "date": "2025-11-19",
                "times": ["09:00 AM", "03:00 PM"],
                "available": 18,
                "total": 25
            },
            {
                "date": "2025-11-26",
                "times": ["09:00 AM"],
                "available": 22,
                "total": 25
            },
            {
                "date": "2025-12-03",
                "times": ["09:00 AM", "03:00 PM"],
                "available": 0,
                "total": 25
            }
        ]
    },
    {
        "id": 4,
        "title": "Goa Beach Paradise",
        "description": "Discover the vibrant beaches of Goa with water sports, beach parties, and coastal exploration. Enjoy parasailing, jet skiing, and relaxing beach yoga sessions in this tropical paradise.",
        "location": "North Goa",
        "price": 5500,
        "currency": "INR",
        "duration": "4 days / 3 nights",
        "image": "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=800",
        "rating": 4.6,
        "reviews": 567,
        "category": "Beach",
        "highlights": [
            "Water sports package",
            "Beach resort stay",
            "Party cruise included",
            "Beachside yoga sessions",
            "Local seafood dining"
        ],
        "slots": [
            {
                "date": "2025-11-14",
                "times": ["10:00 AM"],
                "available": 15,
                "total": 20
            },
            {
                "date": "2025-11-21",
                "times": ["10:00 AM"],
                "available": 12,
                "total": 20
            },
            {
                "date": "2025-11-28",
                "times": ["10:00 AM"],
                "available": 20,
                "total": 20
            },
            {
                "date": "2025-12-05",
                "times": ["10:00 AM"],
                "available": 8,
                "total": 20
            }
        ]
    },
    {
        "id": 5,
        "title": "Taj Mahal & Heritage Tour",
        "description": "Explore India's most iconic monument and the rich heritage of Agra. Visit the magnificent Taj Mahal, Agra Fort, and experience the grandeur of Mughal architecture with expert historians.",
        "location": "Agra, Uttar Pradesh",
        "price": 4500,
        "currency": "INR",
        "duration": "2 days / 1 night",
        "image": "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=800",
        "rating": 4.9,
        "reviews": 892,
        "category": "Heritage",
        "highlights": [
            "Sunrise Taj Mahal visit",
            "Expert historian guide",
            "Agra Fort tour",
            "Local handicraft shopping",
            "Mughlai cuisine experience"
        ],
        "slots": [
            {
                "date": "2025-11-11",
                "times": ["05:30 AM", "06:00 AM"],
                "available": 25,
                "total": 30
            },
            {
                "date": "2025-11-18",
                "times": ["05:30 AM", "06:00 AM"],
                "available": 28,
                "total": 30
            },
            {
                "date": "2025-11-25",
                "times": ["05:30 AM", "06:00 AM"],
                "available": 30,
                "total": 30
            },
            {
                "date": "2025-12-02",
                "times": ["05:30 AM", "06:00 AM"],
                "available": 15,
                "total": 30
            }
        ]
    },
    {
        "id": 6,
        "title": "Rishikesh Yoga Retreat",
        "description": "Find inner peace and rejuvenation at the Yoga capital of the world. Experience authentic yoga and meditation sessions by the holy Ganges, learn from experienced yogis, and immerse in spiritual wellness.",
        "location": "Rishikesh, Uttarakhand",
        "price": 7500,
        "currency": "INR",
        "duration": "5 days / 4 nights",
        "image": "https://images.unsplash.com/photo-1545389336-cf090694435e?w=800",
        "rating": 4.8,
        "reviews": 312,
        "category": "Wellness",
        "highlights": [
            "Daily yoga sessions",
            "Meditation by the Ganges",
            "Ayurvedic meals included",
            "Spiritual workshops",
            "Ashram accommodation"
        ],
        "slots": [
            {
                "date": "2025-11-16",
                "times": ["07:00 AM"],
                "available": 18,
                "total": 20
            },
            {
                "date": "2025-11-23",
                "times": ["07:00 AM"],
                "available": 20,
                "total": 20
            },
            {
                "date": "2025-11-30",
                "times": ["07:00 AM"],
                "available": 14,
                "total": 20
            },
            {
                "date": "2025-12-07",
                "times": ["07:00 AM"],
                "available": 19,
                "total": 20
            }
        ]
    }
]

# Save to JSON file
with open('experiences_data.json', 'w') as f:
    json.dump(experiences, indent=2, fp=f)

print("✓ Created experiences_data.json with 6 travel experiences")
print(f"✓ Total experiences: {len(experiences)}")
print(f"✓ Categories: {len(set(exp['category'] for exp in experiences))}")
print("\nSample experience:")
print(f"- {experiences[0]['title']}")
print(f"- Price: ₹{experiences[0]['price']}")
print(f"- Available slots: {len(experiences[0]['slots'])}")
