const express = require('express');
const router = express.Router();
const PromoCode = require('../models/PromoCode');

// POST /api/promo/validate - Validate promo code
router.post('/validate', async (req, res) => {
  try {
    const { code, amount } = req.body;

    if (!code || !amount) {
      return res.status(400).json({ 
        success: false,
        error: 'Code and amount are required' 
      });
    }

    // Find promo code
    const promo = await PromoCode.findOne({ 
      code: code.toUpperCase(),
      active: true 
    });

    if (!promo) {
      return res.status(404).json({ 
        success: false,
        error: 'Invalid promo code' 
      });
    }

    // Check validity dates
    const now = new Date();
    if (promo.validUntil && promo.validUntil < now) {
      return res.status(400).json({ 
        success: false,
        error: 'Promo code has expired' 
      });
    }

    // Check minimum amount
    if (amount < promo.minAmount) {
      return res.status(400).json({ 
        success: false,
        error: `Minimum order amount is ₹${promo.minAmount}` 
      });
    }

    // Calculate discount
    let discount = 0;
    if (promo.discountType === 'percentage') {
      discount = (amount * promo.discountValue) / 100;
      if (promo.maxDiscount) {
        discount = Math.min(discount, promo.maxDiscount);
      }
    } else {
      discount = promo.discountValue;
    }

    discount = Math.round(discount);

    res.json({
      success: true,
      message: 'Promo code applied successfully',
      data: {
        code: promo.code,
        description: promo.description,
        discountType: promo.discountType,
        discountValue: promo.discountValue,
        discount: discount,
        finalAmount: amount - discount
      }
    });

  } catch (error) {
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

// GET /api/promo - Get all active promo codes
router.get('/', async (req, res) => {
  try {
    const promos = await PromoCode.find({ active: true })
      .select('-__v')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      count: promos.length,
      data: promos
    });
  } catch (error) {
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

module.exports = router;
